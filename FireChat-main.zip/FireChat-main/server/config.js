const { Pool } = require("pg");

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "chat_app",
  password: "992428",
  port: 5432,
});

module.exports = pool;
