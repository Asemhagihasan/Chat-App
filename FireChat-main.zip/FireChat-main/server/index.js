const express = require("express");
const http = require("http");
const bcrypt = require("bcrypt");
const cors = require("cors");
const { Server } = require("socket.io");
const pool = require("./config");

// Initialize Express and HTTP server
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*", methods: ["GET", "POST"] },
});

// Middleware
app.use(express.json());
app.use(cors({ origin: "*" }));

// Helper function to handle errors
const handleError = (res, error, message = "An error occurred") => {
  console.error(message, error);
  res.status(500).send(message);
};

// === Routes ===

// User registration
app.post("/register", async (req, res) => {
  const { display_name, email, password } = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await pool.query(
      "INSERT INTO users (display_name, email, password, status) VALUES ($1, $2, $3, $4) RETURNING *",
      [display_name, email, hashedPassword, true]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    handleError(res, error, "Error registering user");
  }
});

// User login
app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const result = await pool.query("SELECT * FROM users WHERE email = $1", [
      email,
    ]);
    const user = result.rows[0];

    if (!user) return res.status(400).send("User not found");

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).send("Invalid credentials");

    res.status(200).json({ message: "Login successful", user });
  } catch (error) {
    handleError(res, error, "Error logging in");
  }
});

// User logout
app.post("/logout", async (req, res) => {
  const { email } = req.body;

  try {
    await pool.query("UPDATE users SET status = false WHERE email = $1", [
      email,
    ]);
    res.status(200).json({ message: "Logout successful" });
  } catch (error) {
    handleError(res, error, "Error logging out");
  }
});

// Fetch all users
app.get("/users", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT id, display_name, email, status FROM users"
    );
    res.status(200).json(result.rows);
  } catch (error) {
    handleError(res, error, "Error fetching users");
  }
});

// Fetch a single user by ID
app.get("/users/:id", async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query("SELECT * FROM users WHERE id = $1", [id]);
    const user = result.rows[0];

    if (!user) return res.status(404).json({ error: "User not found" });

    res.status(200).json(user);
  } catch (error) {
    handleError(res, error, "Error fetching user");
  }
});

app.get("/messages/:currentChatKey", async (req, res) => {
  const { currentChatKey } = req.params;

  try {
    const result = await pool.query(
      "SELECT * FROM messages WHERE currentChatKey = $1 ORDER BY createdAt ASC",
      [currentChatKey]
    );

    if (result.rows.length === 0) {
      return res
        .status(404)
        .json({ message: "No messages found for this chat key." });
    }

    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error fetching messages:", error);
    res
      .status(500)
      .json({ message: "An error occurred while fetching messages." });
  }
});

// Delete a message by ID
app.post("/messages/delete", async (req, res) => {
  const { ids } = req.body; // Expect an array of message IDs

  if (!Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ message: "Invalid request payload" });
  }

  try {
    // Use the `IN` clause to delete multiple messages at once
    const result = await pool.query(
      "DELETE FROM messages WHERE id = ANY($1::int[])",
      [ids]
    );

    res.status(200).json({ message: "Messages deleted successfully" });
  } catch (error) {
    console.error("Error deleting messages:", error);
    res.status(500).json({ message: "Failed to delete messages" });
  }
});

app.get("/user/:currentUserId/groups", async (req, res) => {
  const { currentUserId } = req.params;
  console.log("userId => ", currentUserId);

  try {
    // Query to get groups the user is part of
    const result = await pool.query(
      `
      SELECT g.id, g.name 
      FROM Groups g
      INNER JOIN GroupMembers gm ON g.id = gm.group_id
      WHERE gm.user_id = $1
      ORDER BY g.name ASC
      `,
      [currentUserId]
    );

    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error fetching user groups:", error.message);
    res.status(500).json({ message: "Server error, please try again later" });
  }
});

app.get("/groups/:groupId", async (req, res) => {
  const { groupId } = req.params;

  try {
    // Query the Groups table for the specific group
    const result = await pool.query(
      `
      SELECT id, name
      FROM Groups
      WHERE id = $1
      `,
      [groupId]
    );

    // Check if the group exists
    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Group not found" });
    }

    // Return the group data
    res.status(200).json(result.rows[0]);
  } catch (error) {
    console.error("Error fetching group by ID:", error.message);
    res.status(500).json({ message: "Server error, please try again later" });
  }
});

app.post("/groups/:groupId/join", async (req, res) => {
  const { groupId } = req.params;
  const { userId } = req.body; // Assuming the user ID is provided in the request body
  const validGroupId = groupId.trim();
  console.log("groupId => ", groupId);
  try {
    // Check if the group exists
    const groupResult = await pool.query(
      "SELECT id FROM Groups WHERE id = $1",
      [validGroupId]
    );
    if (groupResult.rows.length === 0) {
      return res.status(404).json({ message: "Group not found" });
    }

    // Check if the user is already a member of the group
    const membershipResult = await pool.query(
      "SELECT * FROM GroupMembers WHERE user_id = $1 AND group_id = $2",
      [userId, validGroupId]
    );
    if (membershipResult.rows.length > 0) {
      return res
        .status(400)
        .json({ message: "User is already a member of this group" });
    }

    // Add the user to the group
    const insertResult = await pool.query(
      "INSERT INTO GroupMembers (user_id, group_id) VALUES ($1, $2) RETURNING *",
      [userId, validGroupId]
    );

    // Respond with success message
    res.status(201).json({
      message: "User successfully joined the group",
      member: insertResult.rows[0],
    });
  } catch (error) {
    console.error("Error joining group:", error.message);
    res.status(500).json({ message: "Server error, please try again later" });
  }
});

// === Socket.IO ===

// Track connected users
let users = {};
let numberOfUsers = 0;

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  // Register a user with their socket ID
  socket.on("registerUser", async (userId) => {
    users[userId] = socket.id;
    // Update the user's status to online in the database
    try {
      await pool.query("UPDATE users SET status = true WHERE id = $1", [
        userId,
      ]);
      console.log(`User ${userId} marked as online.`);
      io.emit("userStatusUpdated", { userId, status: true });
      io.emit("updateReciverStatus", {
        reciverId: userId,
      });
    } catch (error) {
      console.error("Error updating user status:", error);
    }

    console.log("User registered:", userId, socket.id);
    numberOfUsers++;
    console.log("Number of users:", numberOfUsers);
    console.log("users => ", users);
  });

  // Handle sending messages
  socket.on("sendMessage", async (data) => {
    console.log("Received message:", data);
    const { senderId, reciverId, text, timestamp, senderName, reciverStatus } =
      data;
    const currentChatKey = senderId + "_" + reciverId;
    console.log("currentChatKey => ", currentChatKey);
    const reciverSocketId = users[reciverId];

    if (reciverSocketId) {
      io.to(reciverSocketId).emit("receiveMessage", {
        senderId,
        reciverId,
        senderName,
        text,
        timestamp,
        reciverStatus,
        hasReaded: false,
      });
    } else {
      console.log("Recipient not connected");
      try {
        // Save the message to the database
        console.log("Saving message to the database...", data);
        await pool.query(
          "INSERT INTO messages (content, createdAt, hasReaded, reciverId, reciverStatus ,currentChatKey, senderName, senderId) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)",
          [
            text,
            new Date(Date.now()),
            false,
            reciverId,
            false,
            currentChatKey,
            senderName,
            senderId,
          ]
        );
      } catch (error) {
        console.error("Error sending message:", error);
      }
    }
  });

  // socket.on("updateReciverStatus", (data) => {
  //   console.log("Received updateReciverStatus:", data);
  // });

  //Handle broadcast messages
  // Listen for messages from a client
  socket.on("sendBroadcastMessage", (message) => {
    console.log("Received broadcast message:", message);
    console.log(`Broadcasting message: ${message}`);

    // Broadcast the message to all connected clients
    socket.broadcast.emit("receiveBroadcastMessage", message);
  });

  // Handle group messages
  socket.on("sendGroupMessage", async (data) => {
    const { groupId, senderId, text, timestamp, senderName } = data;

    console.log("aksdk");
    console.log("Received group message:", data);

    try {
      // Fetch group members excluding the sender
      const result = await pool.query(
        `
        SELECT user_id
        FROM GroupMembers
        WHERE group_id = $1 AND user_id != $2
        `,
        [groupId, senderId]
      );

      const groupMembers = result.rows.map((row) => row.user_id);

      // // Store the message in the database
      // await pool.query(
      //   "INSERT INTO messages (content, createdAt, senderId, groupId) VALUES ($1, $2, $3, $4)",
      //   [text, new Date(timestamp), senderId, groupId]
      // );

      // Notify online members
      groupMembers.forEach((memberId) => {
        const memberSocketId = users[memberId]; // `users` maps userId to socketId
        if (memberSocketId) {
          io.to(memberSocketId).emit("receiveGroupMessage", {
            groupId,
            senderId,
            senderName,
            text,
            timestamp,
          });
        }
      });

      console.log(`Message sent to group ${groupId} by user ${senderId}`);
    } catch (error) {
      console.error("Error sending group message:", error);
    }
  });

  // Handle user disconnect
  socket.on("disconnect", async () => {
    let disconnectedUserId;

    for (const userId in users) {
      if (users[userId] === socket.id) {
        disconnectedUserId = userId;
        if (disconnectedUserId) {
          delete users[userId];
          try {
            await pool.query("UPDATE users SET status = false WHERE id = $1", [
              disconnectedUserId,
            ]);
            io.emit("userStatusUpdated", {
              userId: disconnectedUserId,
              status: false,
            });
            console.log(`User ${disconnectedUserId} marked as offline.`);
          } catch (error) {
            console.error("Error updating user status:", error);
          }
          break;
        }
      }
    }

    // if (disconnectedUserId) {
    //   // Update the user's status to offline in the database
    //   try {
    //     await pool.query("UPDATE users SET status = false WHERE id = $1", [
    //       disconnectedUserId,
    //     ]);
    //     io.emit("userStatusUpdated", {
    //       userId: disconnectedUserId,
    //       status: false,
    //     });
    //     console.log(`User ${disconnectedUserId} marked as offline.`);
    //   } catch (error) {
    //     console.error("Error updating user status:", error);
    //   }
    // }
  });
});

// === Start Server ===
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
