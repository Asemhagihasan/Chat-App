// cryptoUtils.js
import CryptoJS from "crypto-js";

const sharedKey =
  "4c8e5b992db4744c3c1f4b2f82d1d2ad87d3b5736a3ecf5a0b3e8b72f3c2af8b"; // Ortak bir şifreleme anahtarı

// Şifreleme fonksiyonu
export const encryptMessage = (message) => {
  return CryptoJS.AES.encrypt(message, sharedKey).toString();
};

// Şifre çözme fonksiyonu
export const decryptMessage = (encryptedMessage) => {
  const bytes = CryptoJS.AES.decrypt(encryptedMessage, sharedKey);
  return bytes.toString(CryptoJS.enc.Utf8);
};

export const generateKey = (user1_id, user2_id) => {
  const key = [user1_id, user2_id].sort().join("_");
  return key;
};

export const calculateUnreadMessages = (messages, chatKey, userId) => {
  return (messages[chatKey] || []).filter(
    (msg) => msg.sender !== userId && !msg.hasReaded
  ).length;
};
