import ReactDOM from "react-dom/client";
import "./index.scss";
import { RouterProvider } from "react-router-dom";
import { router } from "./router.jsx";
import { UserProvider } from "../context/userContext.jsx";
import { ChatProvider } from "../context/MessagesContext.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <UserProvider>
    <ChatProvider>
      <RouterProvider router={router} />
    </ChatProvider>
  </UserProvider>
);
