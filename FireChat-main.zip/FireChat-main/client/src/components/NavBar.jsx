import { useUser } from "../../context/userContext";

function NavBar() {
  const { setUser, user } = useUser();
  const handleLogout = async () => {
    try {
      await fetch("http://localhost:3000/logout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email: user.email }),
      });

      localStorage.removeItem("user");
      setUser(null);
    } catch (err) {
      console.error(err);
    }
  };
  return (
    <div className="navbar">
      <span className="logo">Aleppo Chat</span>
      <div className="user">
        <button onClick={handleLogout}>Logout</button>
      </div>
    </div>
  );
}

export default NavBar;
