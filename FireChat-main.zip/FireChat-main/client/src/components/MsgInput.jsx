/* eslint-disable react/prop-types */

import { AiOutlineSend } from "react-icons/ai";
import { useUser } from "../../context/userContext";
import { encryptMessage } from "../../utils/helper";
import { useChat } from "../../context/MessagesContext";
import useReciverUser from "../../hooks/UseReciverUser";
import { useEffect } from "react";

function MsgInput({ currentChatSelected, socket, text, setText }) {
  const { user } = useUser();
  const { dispatch, state } = useChat();
  const { currentChatKey } = state;
  const currentReciverUser = useReciverUser(currentChatSelected);
  const handleSendMessage = () => {
    if (text.trim()) {
      const message = {
        senderId: user.id,
        reciverId: currentChatSelected,
        senderName: user.display_name,
        text,
        reciverStatus: currentReciverUser?.status,
        timestamp: new Date(Date.now()),
        hasReaded: false,
      };

      dispatch({
        type: "ADD_MESSAGES",
        payload: {
          key: currentChatKey,
          messages: [message],
        },
      });

      const encryptedText = encryptMessage(text); // encrypt the password

      if (currentChatSelected === 0) {
        socket.emit("sendBroadcastMessage", {
          ...message,
          text: encryptedText,
        });
      } else if (typeof currentChatSelected === "number") {
        socket.emit("sendMessage", {
          ...message,
          text: encryptedText,
        });
      } else {
        socket.emit("sendGroupMessage", {
          groupId: currentChatSelected,
          senderId: user.id,
          senderName: user.display_name,
          text: encryptedText,
          timestamp: new Date(Date.now()),
        });
      }
      setText("");
    }
  };

  useEffect(() => {
    const handleStatusUpdate = (data) => {
      let chatKey = `${user.id}_${data.reciverId}`;
      if (!state.messages[chatKey] || chatKey === "1_1") return;
      dispatch({
        type: "UPDATE_MESSAGES",
        payload: {
          key: chatKey,
          updates: { reciverStatus: true },
          updateCondition: () => true,
        },
      });
    };
    socket.on("updateReciverStatus", handleStatusUpdate);
    return () => {
      socket.off("updateReciverStatus", handleStatusUpdate); // Cleanup listener
    };
  }, [socket, dispatch, state, user.id]);

  return (
    <div className="msgInput">
      <input
        type="text"
        name=""
        id=""
        placeholder="Enter Message..."
        onChange={(e) => setText(e.target.value)}
        value={text}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            handleSendMessage();
          }
        }}
      />
      <div className="send">
        <button onClick={handleSendMessage}>
          <AiOutlineSend size={25} />
        </button>
      </div>
    </div>
  );
}

export default MsgInput;
