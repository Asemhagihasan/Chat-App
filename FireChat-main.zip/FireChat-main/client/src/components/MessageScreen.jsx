/* eslint-disable react/prop-types */
import { useEffect } from "react";
import { decryptMessage, generateKey } from "../../utils/helper";
import { useUser } from "../../context/userContext";
import { useChat } from "../../context/MessagesContext";

// Function to format the timestamp to a readable format
const formatTime = (timestamp) => {
  const date = new Date(timestamp);
  return `${date.getHours()}:${date.getMinutes()}`;
};

function MessageScreen({ currentChatSelected, socket }) {
  const { user } = useUser();
  const { dispatch, state } = useChat();
  // the current chat key here it will be the key of the chat we are currently viewing but we need to decrypt the messages with the key of the user who sent the message this why we updated the current chat id inside the useEfact
  const { currentChatKey, messages } = state;
  useEffect(() => {
    // Receiving messages via Socket.io
    socket.on("receiveMessage", (message) => {
      console.log("received message from the server => ", message);
      const decryptedText = decryptMessage(message.text);
      const newMessage = { ...message, text: decryptedText };
      console.log("newMessage => ", newMessage);
      const currentChatKey = generateKey(message.senderId, message.reciverId);
      dispatch({
        type: "ADD_MESSAGES",
        payload: {
          key: currentChatKey,
          messages: [newMessage],
        },
      });
    });

    return () => {
      socket.off("receiveMessage");
    };
  }, [socket, dispatch, currentChatKey]);

  useEffect(() => {
    // Listen for broadcast messages
    socket.on("receiveBroadcastMessage", (message) => {
      console.log("Received broadcast message: ", message);
      const decryptedText = decryptMessage(message.text);
      const newMessage = { ...message, text: decryptedText };
      dispatch({
        type: "ADD_MESSAGES",
        payload: {
          key: "0_" + user.id,
          messages: [newMessage],
        },
      });
    });

    return () => {
      socket.off("receiveBroadcastMessage");
    };
  }, [socket, dispatch, currentChatKey]);

  useEffect(() => {
    socket.on("receiveGroupMessage", (message) => {
      console.log("Group message received:", message);
      const decryptedText = decryptMessage(message.text);
      const newMessage = { ...message, text: decryptedText };
      dispatch({
        type: "ADD_MESSAGES",
        payload: {
          key: user.id + "_" + message.groupId,
          messages: [newMessage],
        },
      });
    });

    return () => {
      socket.off("receiveGroupMessage");
    };
  }, [socket]);

  useEffect(() => {
    // Update `hasReaded` status for messages in the current chat
    if (currentChatKey && messages[currentChatKey]) {
      dispatch({
        type: "UPDATE_MESSAGES",
        payload: {
          key: currentChatKey,
          updateCondition: (msg) => msg.sender !== user.id && !msg.hasReaded, // Update unread messages from other users
          updates: { hasReaded: true },
        },
      });
    }
  }, [currentChatSelected, currentChatKey, dispatch, user.id]);

  useEffect(() => {
    const fetchUnReadMessages = async () => {
      if (
        currentChatKey !== `0_${user.id}` &&
        currentChatKey !== 0 &&
        typeof currentChatSelected === "number"
      ) {
        try {
          const response = await fetch(
            `http://localhost:3000/messages/${currentChatKey}`
          );
          if (!response.ok) {
            throw new Error("Failed to fetch messages");
          }
          const data = await response.json();
          console.log("data => ", data);
          const messageIdsToDelete = [];
          for (let i = 0; i < data.length; i++) {
            const decryptedText = decryptMessage(data[i].content);
            const newMessage = { ...data[i], text: decryptedText };
            if (currentChatSelected === newMessage.senderid) {
              dispatch({
                type: "ADD_MESSAGES",
                payload: {
                  key: currentChatKey,
                  messages: [newMessage],
                },
              });
              messageIdsToDelete.push(newMessage.id); // Add message ID to list
            }
          }
          // Send a request to delete messages
          if (messageIdsToDelete.length > 0) {
            await fetch("http://localhost:3000/messages/delete", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ ids: messageIdsToDelete }),
            });
            console.log("Messages deleted successfully");
          }
        } catch (error) {
          console.error("Error fetching unread messages:", error);
        }
      }
    };

    fetchUnReadMessages();
  }, [currentChatKey, dispatch, user.id]);

  return (
    <div className="messageScreen">
      <div className="messageContainer">
        {(messages[currentChatKey] || []).map((message, index) => (
          <div key={index} className="message">
            <div
              className={`messageContent ${
                message.senderId === user.id ? "sender" : "reciver"
              }`}
            >
              <div className="messageWrapper">
                <div className="messageInfo">
                  {currentChatSelected === 0 && (
                    <p className="messageSender">{message.senderName}</p>
                  )}
                  <p className="messageText">
                    {message.text || message.content}
                  </p>
                </div>
                <span className="messageTime">
                  {formatTime(message.createdat || message.timestamp)}
                </span>
              </div>
              {message.senderId === user.id && (
                <span className="messageStatus">
                  {message.reciverStatus === true ? "✔✔" : "✔"}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default MessageScreen;
