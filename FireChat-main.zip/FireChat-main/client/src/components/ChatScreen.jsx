/* eslint-disable react/prop-types */
import { useEffect, useState } from "react";
import MessageScreen from "./MessageScreen";
import MsgInput from "./MsgInput";
import { generateKey } from "../../utils/helper";
import { useUser } from "../../context/userContext";
import { useChat } from "../../context/MessagesContext";
import useReciverUser from "../../hooks/UseReciverUser";

function ChatScreen({ currentChatSelected, socket, activeOption }) {
  const [text, setText] = useState("");
  const { user } = useUser();
  const { dispatch } = useChat();
  const currentChatKey = generateKey(currentChatSelected, user.id);
  const currentReciverChat = useReciverUser(currentChatSelected, activeOption);

  useEffect(() => {
    dispatch({ type: "SET_CURRENT_CHAT_KEY", payload: currentChatKey });
    setText("");
  }, [currentChatSelected, user.id, dispatch, currentChatKey]);
  return (
    <div className="chatScreen">
      <div className="chatInfo">
        {activeOption === "groups" ? (
          <>
            <span>{currentReciverChat?.name}</span>
          </>
        ) : (
          <>
            <span>
              Chat with {currentReciverChat?.display_name || "Main group"}
            </span>
          </>
        )}
      </div>
      <MessageScreen
        socket={socket}
        currentChatSelected={currentChatSelected}
      />
      <MsgInput
        text={text}
        setText={setText}
        socket={socket}
        currentChatSelected={currentChatSelected}
      />
    </div>
  );
}

export default ChatScreen;
