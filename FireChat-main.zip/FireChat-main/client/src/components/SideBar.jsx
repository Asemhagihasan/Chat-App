// import NavBar from "./NavBar";
// import Chats from "./Chats";

// function SideBar() {
//   return (
//     <div className="sidebar">
//       <NavBar />
//       <Chats />
//     </div>
//   );
// }

// export default SideBar;
