import { useState } from "react";

function Search() {
  const [userName, setUserName] = useState("");

  return (
    <div className="search">
      <div className="searchForm">
        <input
          type="text"
          name=""
          id=""
          placeholder="Search Users....."
          onChange={(e) => setUserName(e.target.value)}
          value={userName}
        />
      </div>
    </div>
  );
}

export default Search;
