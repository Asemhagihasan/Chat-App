import { useState } from "react";
import { useUser } from "../../context/userContext";

export default function JoinGroup({ setReFetch }) {
  const [groupId, setGroupId] = useState("");
  const { user: currentUser } = useUser();
  const handleSubmit = async (e) => {
    e.preventDefault();
    const sanitizedGroupId = groupId.trim();
    console.log("sanitizedGroupId => ", sanitizedGroupId);
    try {
      const response = await fetch(
        `http://localhost:3000/groups/${groupId}/join`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            groupId: sanitizedGroupId,
            userId: currentUser.id,
          }),
        }
      );

      if (response.ok) {
        const data = await response.json();
        console.log(data);
        setReFetch(true);
        alert("Group joined successfully!");
      } else {
        const errorData = await response.json();
        console.error(errorData);
      }

      setGroupId("");
    } catch (error) {
      console.error(error);
    }
  };
  return (
    <div style={styles.container}>
      <form onSubmit={handleSubmit} style={styles.form}>
        <label htmlFor="groupId" style={styles.label}>
          Group ID:
        </label>
        <input
          type="text"
          id="groupId"
          value={groupId}
          onChange={(e) => setGroupId(e.target.value)}
          style={styles.input}
          required
        />
        <button type="submit" style={styles.button}>
          Join Group
        </button>
      </form>
    </div>
  );
}
const styles = {
  container: {
    maxWidth: "400px",
    padding: "20px",
    // border: "1px solid #ddd",
    borderRadius: "5px",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    marginTop: "20px",
  },
  label: {
    margin: "10px 0 5px",
    color: "#fff",
  },
  input: {
    padding: "10px",
    margin: "5px 0 15px",
    border: "1px solid #ddd",
    borderRadius: "5px",
  },
  button: {
    padding: "10px",
    backgroundColor: "#2f2d52",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
};
