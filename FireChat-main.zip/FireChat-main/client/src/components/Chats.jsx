// import { useEffect, useState } from "react";
// import { useUser } from "../../context/userContext";
// import { useNavigate } from "react-router-dom";

// function Chats() {
//   const [error, setError] = useState(null);
//   const { user: currentUser } = useUser(); // Get the current user
//   const [chats, setChats] = useState([]);

//   useEffect(() => {
//     const fetchUsers = async () => {
//       try {
//         const response = await fetch("http://localhost:3000/users");
//         if (!response.ok) {
//           throw new Error("Failed to fetch users");
//         }
//         const data = await response.json();

//         // Exclude the current user
//         if (currentUser) {
//           const filteredUsers = data.filter(
//             (user) => user.id !== currentUser.id
//           );
//           setChats(filteredUsers);
//         } else {
//           setChats(data);
//         }
//       } catch (err) {
//         console.error(err);
//         setError(err.message);
//       }
//     };

//     fetchUsers();
//   }, [currentUser]); // Depend on currentUser to avoid stale data

//   if (error) {
//     return <div className="error">{error}</div>;
//   }

//   return (
//     <div className="chats">
//       <div className={`userChat`}>
//         <div className="userChatInfo">
//           <span>Main Chat</span>
//         </div>
//       </div>
//       {chats.length > 0 ? (
//         chats.map((chat) => (
//           <div className={`userChat`} key={chat.id}>
//             <div className="userChatInfo">
//               <span>{chat.display_name || "Main group"}</span>
//             </div>
//           </div>
//         ))
//       ) : (
//         <div className="noChats">No users available</div>
//       )}
//     </div>
//   );
// }

// export default Chats;
