import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useUser } from "../../context/userContext";

function Login() {
  const [error, setError] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { setUser } = useUser();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      setError("Please fill in all fields");
    }
    try {
      const response = await fetch("http://localhost:3000/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });
      const data = await response.json();
      if (response.ok) {
        setUser(data.user);
        navigate("/home");
      } else {
        setError(data.error || "An error occurred during login");
      }
    } catch (err) {
      setError(err.message || "Some thing went wrong");
    }
  };

  return (
    <div className="formContainer">
      <div className="formWrapper">
        <span className="logo">FireChat</span>
        <span className="title">Login</span>
        <form>
          <input
            type="email"
            placeholder="e-Mail"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          {error && (
            <span
              className="title"
              style={{ color: "#f00", fontSize: "0.8em" }}
            >
              {error}
            </span>
          )}
          <button onClick={handleLogin}>Login</button>
        </form>
        <p>
          No Account? <Link to="/signup">Register now</Link>
        </p>
      </div>
    </div>
  );
}

export default Login;
