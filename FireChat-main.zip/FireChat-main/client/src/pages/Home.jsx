import ChatScreen from "../components/ChatScreen";
import { useUser } from "../../context/userContext";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import Navbar from "../components/NavBar";
import io from "socket.io-client";
import { useChat } from "../../context/MessagesContext";
import JoinGroup from "../components/JoinGroup";

const socket = io("http://localhost:3000");

function Home() {
  const { user } = useUser();
  const navigate = useNavigate();
  const [error, setError] = useState(null);
  const { user: currentUser } = useUser(); // Get the current user
  const [chats, setChats] = useState([]);
  const [groups, setGroups] = useState([]);
  const [activeOptions, setActiveOptions] = useState([]);
  const [activeOption, setActiveOption] = useState("chats");
  const [reFatch, setReFetch] = useState(false);
  const [currentChatSelected, setCurrentChatSelected] = useState(0);

  const handleOptionClick = (option) => {
    setActiveOption(option);
    setCurrentChatSelected(0);
  };

  const handleChatSelect = (chatId) => {
    setCurrentChatSelected(chatId);
  };

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch("http://localhost:3000/users");
        if (!response.ok) {
          throw new Error("Failed to fetch users");
        }
        const data = await response.json();

        // Exclude the current user
        if (currentUser) {
          const filteredUsers = data.filter(
            (user) => user.id !== currentUser.id
          );
          setChats(filteredUsers);
        } else {
          setChats(data);
        }
      } catch (err) {
        setError(err.message);
      }
    };

    fetchUsers();
  }, [currentUser]); // Depend on currentUser to avoid stale data

  useEffect(() => {
    // Fetch user's groups using fetch API
    const fetchGroups = async () => {
      try {
        const response = await fetch(
          `http://localhost:3000/user/${currentUser.id}/groups`
        );
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        setGroups(data);
      } catch (error) {
        console.error("Error fetching groups:", error);
      }
    };

    fetchGroups();
  }, [currentUser.id, reFatch]);

  useEffect(() => {
    if (!user?.display_name) {
      navigate("/login");
    }
  }, [user.display_name, navigate]);

  useEffect(() => {
    if (user && user.id) {
      socket.emit("registerUser", user.id);
    }
  }, [user]);

  useEffect(() => {
    // Listen for user status updates
    socket.on("userStatusUpdated", (update) => {
      setChats((prevChats) =>
        prevChats.map((chat) =>
          chat.id === update.userId ? { ...chat, status: update.status } : chat
        )
      );
    });

    return () => {
      socket.off("userStatusUpdated");
    };
  }, []);

  useEffect(() => {
    if (activeOption === "chats") {
      setActiveOptions(chats);
    } else if (activeOption === "groups") {
      setActiveOptions(groups);
    }
  }, [activeOption, chats, groups]);

  if (error) alert(error);

  return (
    <div className="home">
      <div className="container">
        <div className="sidebar">
          <Navbar />
          <div>
            <button onClick={() => handleOptionClick("chats")} className="btn">
              Chats
            </button>
            <button onClick={() => handleOptionClick("groups")} className="btn">
              Groups
            </button>
          </div>
          <div className="chats">
            {activeOptions === chats && (
              <div
                className={`userChat ${
                  currentChatSelected === 0 ? "activeChat" : ""
                }`}
                onClick={() => setCurrentChatSelected(0)}
              >
                <div className="userChatInfo">
                  <span className="main">Main Chat</span>
                </div>
              </div>
            )}
            {activeOptions.map((chat) => (
              <div
                className={`userChat ${
                  currentChatSelected === chat.id ? "activeChat" : ""
                }`}
                key={chat.id}
                onClick={() => handleChatSelect(chat.id)}
              >
                <div className="userChatInfo">
                  <p>{chat.display_name || chat.name || "Main group"}</p>
                  {activeOption === "chats" && (
                    <span>{chat.status === true ? "🟢" : "🔴"}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <ChatScreen
          activeOption={activeOption}
          socket={socket}
          currentChatSelected={currentChatSelected}
        />
        {activeOption === "groups" && <JoinGroup setReFetch={setReFetch} />}
      </div>
    </div>
  );
}

export default Home;
