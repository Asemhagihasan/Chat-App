import { useEffect, useState } from "react";

const useReciverUser = (currentChatSelected, activeOption) => {
  const [chat, setChat] = useState(null);

  useEffect(() => {
    const fetchUserOrGroup = async () => {
      // Clear chat when switching options or chats
      setChat(null);

      // Don't fetch for invalid chat selections
      if (currentChatSelected === 0) return;

      try {
        if (activeOption === "groups") {
          console.log("Fetching group data...");
          const response = await fetch(
            `http://localhost:3000/groups/${currentChatSelected}`
          );
          if (!response.ok) {
            throw new Error(`Failed to fetch group: ${response.status}`);
          }
          const groupData = await response.json();
          setChat(groupData);
        } else if (activeOption === "chats") {
          console.log("Fetching user data...");
          const response = await fetch(
            `http://localhost:3000/users/${currentChatSelected}`
          );
          if (!response.ok) {
            throw new Error(`Failed to fetch user: ${response.status}`);
          }
          const userData = await response.json();
          setChat(userData);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchUserOrGroup();
  }, [currentChatSelected, activeOption]); // Add activeOption as dependency

  return chat;
};

export default useReciverUser;
