/* eslint-disable react/prop-types */
import { createContext, useReducer, useContext } from "react";

const ChatContext = createContext();

const initialState = {
  currentChatKey: 0,
  messages: {}, // e.g., { 'omar_asem': [{...}, {...}], 'main_chat': [{...}] }
};

const chatReducer = (state, action) => {
  switch (action.type) {
    case "SET_CURRENT_CHAT_KEY":
      return { ...state, currentChatKey: action.payload };
    case "ADD_MESSAGES":
      return {
        ...state,
        messages: {
          ...state.messages,
          [action.payload.key]: [
            ...(state.messages[action.payload.key] || []),
            ...action.payload.messages,
          ],
        },
      };
    case "UPDATE_MESSAGES":
      return {
        ...state,
        messages: {
          ...state.messages,
          [action.payload.key]: state.messages[action.payload.key]?.map((msg) =>
            action.payload.updateCondition(msg)
              ? { ...msg, ...action.payload.updates }
              : msg
          ),
        },
      };
    default:
      return state;
  }
};

export const ChatProvider = ({ children }) => {
  const [state, dispatch] = useReducer(chatReducer, initialState);

  return (
    <ChatContext.Provider value={{ state, dispatch }}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => useContext(ChatContext);
