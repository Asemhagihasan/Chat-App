import { createContext, useState, useEffect, useContext } from "react";

// Create the UserContext
const UserContext = createContext();

// UserContext provider component
const UserProvider = ({ children }) => {
  const storedUserData = localStorage.getItem("user");
  const parsedUserData = storedUserData ? JSON.parse(storedUserData) : {};
  const [user, setUser] = useState(parsedUserData);

  useEffect(() => {
    localStorage.setItem("user", JSON.stringify(user));
  }, [user]);

  return (
    <UserContext.Provider value={{ user, setUser }}>
      {children}
    </UserContext.Provider>
  );
};

function useUser() {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
}

export { UserProvider, useUser };
